﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CrudApi.Models;
using CrudApi.Persistence;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CrudApi.Controllers
{
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        IEmployeeRepository repository;

        public EmployeeController(IEmployeeRepository repo)
        {
            repository = repo;
        }

        public string RandomString(int size, bool lowerCase)
        {
            StringBuilder builder = new StringBuilder();
            Random random = new Random();
            char ch;
            for (int i = 0; i < size; i++)
            {
                ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                builder.Append(ch);
            }
            if (lowerCase)
                return builder.ToString().ToLower();
            return builder.ToString();
        }


        [HttpGet]
        public virtual IActionResult GetAllEmployee()
        {
            return this.Ok(repository.List());
        }

        [HttpGet("{id}")]
        public IActionResult GetEmployee(string id)
        {
            Employee employee = repository.Get(id);

            if (employee != null) // I HATE NULLS, MUST FIXERATE THIS.			  
            {
                return this.Ok(employee);
            }
            else
            {
                return this.NotFound();
            }
        }

        [HttpPost]
        public virtual IActionResult CreateEmployee([FromBody]Employee newEmployee)
        {
            //repository.Add(newEmployee);
            newEmployee.ID = RandomString(10, true);
            repository.Add(newEmployee);
            
            return this.Created($"/employee/{newEmployee.ID}", newEmployee);
        }

        [HttpPut("{id}")]
        public virtual IActionResult UpdateEmployee([FromBody]Employee employee, string id)
        {
            employee.ID = id;

            if (repository.Update(employee) == null)
            {
                return this.NotFound();
            }
            else
            {
                return this.Ok(employee);
            }
        }

        [HttpDelete("{id}")]
        public virtual IActionResult DeleteEmployee(string id)
        {
            Employee employee= repository.Delete(id);

            if (employee == null)
            {
                return this.NotFound();
            }
            else
            {
                return this.Ok(employee.ID);
            }
        }

    }
}
