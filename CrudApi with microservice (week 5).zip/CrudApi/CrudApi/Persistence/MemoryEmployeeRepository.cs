﻿using CrudApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudApi.Persistence
{
    public class MemoryEmployeeRepository : IEmployeeRepository
    {
        protected static ICollection<Employee> employees;

        public MemoryEmployeeRepository()
        {
            if (employees == null)
            {
                employees = new List<Employee>();
            }
        }

        public MemoryEmployeeRepository(ICollection<Employee> employees)
        {
            MemoryEmployeeRepository.employees = employees;
        }

        public IEnumerable<Employee> List() {
            return employees;
        }

        public Employee Get(string id) {
            return employees.FirstOrDefault(t => t.ID == id);
        }

        public Employee Update(Employee e)
        {
            Employee employee = this.Delete(e.ID);

            if (employee != null)
            {
                employee = this.Add(e);
            }

            return employee;
        }

        public Employee Add(Employee e)
        {
            employees.Add(e);
            return e;
        }

        public Employee Delete(string id)
        {
            var q = employees.Where(t => t.ID == id);
            Employee employee = null;

            if (q.Count() > 0)
            {
                employee = q.First();
                employees.Remove(employee);
            }

            return employee;
        }
    }
}
