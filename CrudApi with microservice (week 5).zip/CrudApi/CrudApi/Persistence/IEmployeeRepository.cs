﻿using CrudApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudApi.Persistence
{
    public interface IEmployeeRepository
    {
        IEnumerable<Employee> List();
        Employee Get(string id);
        Employee Add(Employee employee);
        Employee Update(Employee employee);
        Employee Delete(string id);
    }
}
