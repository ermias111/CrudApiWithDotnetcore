﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudApi.Models
{
    public class Employee
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string Position { get; set; }
        public string Office { get; set; }
        public int Salary { get; set; }

        public Employee()
        {

        }

        /*
         * public Employee(string name)
        {
            this.Name = name;
        }*/

        public Employee(string id)
        {
            this.ID = id;
        }

        public Employee(string name, string position, int salary, string office, string id) : this(id)
        {
            this.Name = name;
            this.Position = position;
            this.Office = office;
            this.Salary = salary;
        }

        public override string ToString()
        {
            return this.Name;
        }

    }
}
